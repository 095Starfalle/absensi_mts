<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-27 11:56:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 11:56:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 11:56:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 11:56:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 11:56:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 11:56:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:01:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
ERROR - 2025-05-27 12:03:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\absensi_mts\bcit-ci-CodeIgniter-bcb17eb\system\core\Loader.php 349
